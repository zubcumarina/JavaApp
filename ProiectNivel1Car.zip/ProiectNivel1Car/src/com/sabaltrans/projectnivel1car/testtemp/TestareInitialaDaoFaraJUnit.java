///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package com.sabaltrans.projectnivel1car.testtemp;
//
//
//import java.sql.SQLException;
//import java.util.List;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//
///**
// *
// * @author user
// */
//public class TestareInitialaDaoFaraJUnit {
//    private static final Logger LOG = Logger.getLogger(TestareInitialaDaoFaraJUnit.class.getName());
//
//    //acces la metodele din impl
//    static UserLoginDaoIntf userDao = new UserLoginDaoImpl();
//
//    public static void main(String[] args) {
//        testareFindAll();
//    }
//
//    private static void testareFindAll() {
//        try {
//            List<UserLogin> listDB = userDao.findAll();
//            printList(listDB);
//        } catch (SQLException ex) {
//            Logger.getLogger(TestareInitialaDaoFaraJUnit.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//
//    private static void printList(List<UserLogin> listDB) {
//        //printf-tipareste cu formatare
//        System.out.print("-------------------------------------------------\n");
//        System.out.printf("|%-4s|%-20s|%-10s|%-10s|\n", "ID", "USERNAME", "PASSWORD", "DATA");
//        System.out.print("-------------------------------------------------\n");
//        
//        for (UserLogin ul : listDB) {
//
//            System.out.printf("|%-4s|%-20s|%-10s|%-10s|\n", ul.getId(), ul.getUsername(), ul.getPassword(), ul.getConnectionDate());
//        }
//
//    }
//}
