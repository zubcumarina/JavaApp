package com.sabaltrans.projectnivel1car;

import com.sabaltrans.projectnivel1car.db.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProjectNivel2Car {
    
    
    public static void main(String[] args) {
       
       DataSource ds = DataSource.getInstance();
       
       String sql = "SELECT  * FROM CARS";
             
        try {
            
            Connection connection = ds.getConnection();
            Statement stat  = connection.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            
            while (rs.next()){
                int id = rs.getInt(1);
                String userName = rs.getString(2);
                String password = rs.getString(3);
                LocalDate data = rs.getDate(4).toLocalDate();
                System.out.println("id =" + id + "userName=" + userName + "password=" + password + "data="+ data);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProjectNivel2Car.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
