package com.sabaltrans.projectnivel1car.dao;

import java.util.List;
import com.sabaltrans.projectnivel1car.models.Car;

public interface CarInterface {

//CRUD-in aceaste interfete se scriu metodele CRUD - de creare, citire,update si stergere
//(create,read,update,delete),MET DE BAZA CIND VREM SA LUCRAM CU OBIECTUL CREAT
    
    void saveCar(Car car);
    void updateCar(Car car);
    void deleteCar(Car car);   
    
    Car findByBrand(String Brand);
    Car findById(int Id);
    
    List<Car>findAll();

    
}
