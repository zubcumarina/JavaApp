package com.sabaltrans.projectnivel1car.dao.implement;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.sabaltrans.projectnivel1car.models.Car;
import com.sabaltrans.projectnivel1car.dao.FileIOMockIntf;
import com.sabaltrans.projectnivel1car.util.CsvUtil;

public class FileIOMockImpl implements FileIOMockIntf {

    @Override
    public void saveToFile(String fileName, List<Car> lista) {
        //parcurge lista,extrage fiecare car si al transforma intr-un string
        //filewriter-citeste un fisier si inscrie fisierul

        //try-catch -->trat exceptii-din fisier spre baza de date si invers apar sit exceptionale
        //try (cu resurse) ne ajuta sa rulam fara a fol finally, citirea flux de info se inkide automat dupa util
        try (FileWriter fw = new FileWriter(fileName)) {

            for (Car car : lista) {   //se iter listei, se transm lista ca parametru-cea pe care vrem so salvam,
                //se extrage din lista cite 1car si se pastreaza intr-o var de tip car, 

                String linie = CsvUtil.carToLine(car);
                //car se transm ca param a metodei carToLine ce se afla in clasa CsvUtil, rezultatul primit este de tip String si se pastr in var linie.

                fw.write(linie);//apel met write ca sa scrie linia
            }    //daca la try merge ok cod nu se exec catch altfel se afis mes de eroare    
        } catch (Exception e) {
            System.err.print(e);
        }

    }

    @Override
    public List<Car> readFile(String fileName) {

        //preg lista pu car. cu interfata nu putem crea obiecte dar cu clase concrete!!
        List<Car> listCars = new ArrayList<>();

        try ( //cod pu executare
                FileReader fr = new FileReader(fileName);
                BufferedReader br = new BufferedReader(fr);) {
            
            String linie = null;
            while((linie = br.readLine()) !=null){
                Car car = CsvUtil.lineToCar(linie);
                listCars.add(car);
            }

        } catch (IOException ex) {
            //cod in caz de exceptie
            System.err.println(ex.toString());

        }
return listCars;
    }

}
