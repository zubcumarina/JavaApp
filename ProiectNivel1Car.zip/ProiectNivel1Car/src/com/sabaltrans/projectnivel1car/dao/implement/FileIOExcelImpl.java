package com.sabaltrans.projectnivel1car.dao.implement;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.sabaltrans.projectnivel1car.models.Car;
import com.sabaltrans.projectnivel1car.dao.FileIOMockIntf;

public class FileIOExcelImpl implements FileIOMockIntf {

    @Override
    public void saveToFile(String fileName, List<Car> lista) {

        XSSFWorkbook wb = new XSSFWorkbook();
        Sheet carSheet = wb.createSheet("List cars");

        int rowIndex = 0;
        for (Car car : lista) {
            Row row = carSheet.createRow(rowIndex++);

            int cellIndex = 0;
            row.createCell(cellIndex++).setCellValue(car.getBrand());
            row.createCell(cellIndex++).setCellValue(car.getModel());
            row.createCell(cellIndex++).setCellValue(car.getId());
            row.createCell(cellIndex++).setCellValue(car.getYear().toString());
            row.createCell(cellIndex++).setCellValue(car.getPrice());
            row.createCell(cellIndex++).setCellValue(car.getColor());
            row.createCell(cellIndex++).setCellValue(car.getEngineCapacity());
            row.createCell(cellIndex++).setCellValue(car.getSpeedMax());
            row.createCell(cellIndex++).setCellValue(car.getNoDoors());
            row.createCell(cellIndex++).setCellValue(car.getConsumption());
            row.createCell(cellIndex++).setCellValue(car.getGearbox());
            row.createCell(cellIndex++).setCellValue(car.getTraction());
        }

        FileOutputStream fos;
        try {
            fos = new FileOutputStream(fileName);
            wb.write(fos);
            fos.close();

        } catch (Exception ex) {
            System.err.print(ex.toString());
        }
    }

    @Override
    public List<Car> readFile(String fileName) {

        List<Car> listCars = new ArrayList<>();

        try {
            FileInputStream fis = new FileInputStream(fileName);

            XSSFWorkbook wb = new XSSFWorkbook(fis);
            
            Sheet sheet = wb.getSheetAt(0);
            
            Iterator  rowIterator = sheet.iterator();
            while(rowIterator.hasNext()){
                Car car = new Car();
                Row row = (Row) rowIterator.next();//next citeste rindul
                
              
                //while pu celule-coloane
                    Iterator cellIterator = row.iterator();                        
                    while(cellIterator.hasNext()){
                        Cell cell = (Cell) cellIterator.next();
                      
                        if(cell.getColumnIndex()==0){
                            car.setBrand(cell.getStringCellValue());
                        }else if (cell.getColumnIndex()==1){
                            car.setModel(cell.getStringCellValue());
                            
                        }else if (cell.getColumnIndex()==2){
                            car.setID((int)cell.getNumericCellValue());
                            
                        }else if (cell.getColumnIndex()==3){
                            car.setYear((LocalDate.parse(cell.getStringCellValue(), DateTimeFormatter.ISO_DATE)));
                        }else if (cell.getColumnIndex()==4){
                            car.setPrice((int)cell.getNumericCellValue());
                        }else if (cell.getColumnIndex()==5){
                            car.setColor(cell.getStringCellValue());
                        }else if (cell.getColumnIndex()==6){
                            car.setEngineCapacity(cell.getNumericCellValue());
                        }else if (cell.getColumnIndex()==7){
                            car.setSpeedMax((int) cell.getNumericCellValue());
                        }else if (cell.getColumnIndex()==8){
                            car.setNoDoors((int) cell.getNumericCellValue());
                        }else if (cell.getColumnIndex()==9){
                            car.setConsumption(cell.getStringCellValue());
                        }else if (cell.getColumnIndex()==10){
                            car.setGearbox(cell.getStringCellValue());
                        }else if (cell.getColumnIndex()==11){
                            car.setTraction(cell.getStringCellValue());
                        }                   
                }
                    listCars.add(car);
        }
                   fis.close();
                   wb=null;
                   return listCars;
                   
        } catch (Exception ex) {
            System.err.println(ex.toString());
        }
        return listCars;
        }

}
