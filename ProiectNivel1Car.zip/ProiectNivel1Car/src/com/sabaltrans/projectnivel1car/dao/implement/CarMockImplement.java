package com.sabaltrans.projectnivel1car.dao.implement;

import java.util.ArrayList;
import java.util.List;
import com.sabaltrans.projectnivel1car.models.Car;
import com.sabaltrans.projectnivel1car.dao.CarInterface;

public class CarMockImplement implements CarInterface {

    List<Car> listCars;

    public CarMockImplement() {
        listCars = new ArrayList<>();
    }

    public CarMockImplement(List<Car> listCars) {
        this.listCars = listCars;
    }

    @Override
    public void saveCar(Car car) {
        listCars.add(car);
    }

    @Override
    public void updateCar(Car car) {
      for (int i = 0; i < listCars.size(); i++) {                //cauta in lista
            if (listCars.get(i).getBrand().equals(car.getBrand())) {  //extrage cite o masina
                listCars.set(i, car);                                //extrage brandul-prin metoda set(i-index elem, car-elem cu care va fi inlocuit)
                break;
            }
        }           
    }
  
    @Override
    public void deleteCar(Car car) {
        for (int i = 0; i < listCars.size(); i++) {
            if (listCars.get(i).getBrand().equals(car.getBrand())) {
                listCars.remove(i);//remove-a sterge un elem
                break;
            }
        }
    }

    @Override
    public Car findByBrand(String Brand) {
        Car brandCautat = null;

        for (int i = 0; i < listCars.size(); i++) {
            if (listCars.get(i).getBrand().equals(Brand)) {//equals-la date de referinta
        // if (listCars.get(i).getId()==Id) {--cautarea datelor de tip primitiv-int
                brandCautat = listCars.get(i);//get-a acesa un elem
                //iesire fortat din ciclu asta dupa ce a gasit elementul cautat
                break;
            }
        }
        return brandCautat;

    }

    @Override
    public Car findById(int Id) {
       Car idCautat = null;

        for (int i = 0; i < listCars.size(); i++) {
            if (listCars.get(i).getId()==Id) {//equals-la date de referinta
        // if (listCars.get(i).getId()==Id) {--cautarea datelor de tip primitiv-int
                idCautat = listCars.get(i);//get-a acesa un elem
                //iesire fortat din ciclu asta dupa ce a gasit elementul cautat
                break;
            }
        }
        return idCautat;
   }

    @Override
    public List<Car> findAll() {
        return listCars;
    }


}
