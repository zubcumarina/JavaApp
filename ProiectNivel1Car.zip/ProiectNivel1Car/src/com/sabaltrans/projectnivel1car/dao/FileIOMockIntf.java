package com.sabaltrans.projectnivel1car.dao;

import java.util.List;
import com.sabaltrans.projectnivel1car.models.Car;

/**
 *
 * @author user
 */
public interface FileIOMockIntf {
    
    void saveToFile(String fileName, List<Car> lista);
    List<Car>readFile(String fileName);
    
}

