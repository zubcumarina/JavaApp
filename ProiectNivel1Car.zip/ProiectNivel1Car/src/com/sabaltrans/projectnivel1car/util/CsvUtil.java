package com.sabaltrans.projectnivel1car.util;

import java.time.LocalDate;
import com.sabaltrans.projectnivel1car.models.Car;

/**
 *
 * @author user
 */
public class CsvUtil {

    public static final String CSV = ","; //obiectul va avea parametrii separati prin virgula
    public static final String EOL = "\n";//endofline-backslash  

    //2metode 
    //1metoda. ce transf un obiect de tip angajat intr-o linie/rind
    //  2.ia rindul si il imparte in bucati ca sa formeze un obiect de tip Angajat
    public static String carToLine(Car car) {

        StringBuilder sb = new StringBuilder();
        sb.append(car.getBrand());  //BMW
        sb.append(CSV);                 //BMW,

        sb.append(car.getModel());  //BMW,Rapid
        sb.append(CSV);//BMW,Rapid,

        sb.append(car.getId());  //BMW, Rapid,11D
        sb.append(CSV);//BMW,Rapid,11D,

        sb.append(car.getYear());  //BMW,Rapid,11D,2010
        sb.append(CSV);//BMW,Rapid,11D,2010,

        sb.append(car.getPrice());
        sb.append(CSV);

        sb.append(car.getColor());
        sb.append(CSV);

        sb.append(car.getEngineCapacity());
        sb.append(CSV);

        sb.append(car.getSpeedMax());
        sb.append(CSV);

        sb.append(car.getNoDoors());
        sb.append(CSV);

        sb.append(car.getConsumption());
        sb.append(CSV);

        sb.append(car.getGearbox());
        sb.append(CSV);

        sb.append(car.getTraction());
        sb.append(EOL);

        sb.trimToSize();
        return sb.toString(); //"BMW, Rapid, 11D,2010, 15000$, Black, ..."
    }

    public static Car lineToCar(String line) {
        //0       1         2       3            4
        String[] valori = line.split(CSV);  //  {"BMW","Rapid","11D","2010","15000$"...
        String Brand = valori[0];  //"BMW"
        String Model = valori[1];
        int Id = Integer.parseInt(valori[2]);
        LocalDate year = LocalDate.parse(valori[3]);
        int price = Integer.parseInt(valori[4]);  
        String color = valori[5];  
        double engineCapacity = Double.parseDouble(valori[6]);  
        int speedMax = Integer.parseInt(valori[7]);  
        int noDoors = Integer.parseInt(valori[8]);  
        String consumption = valori[9];  
        String gearBox = valori[10];
        String traction = valori[11];
        
        Car carExtras = new Car(Brand, Model, Id, year, price, color, engineCapacity, speedMax, noDoors, consumption, gearBox, traction);
   
        return carExtras;
    
    }
}
