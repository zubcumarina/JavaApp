package com.sabaltrans.projectnivel1car.models;

import java.time.LocalDate;
import java.util.Objects;

public class Car {

    private String brand;
    private String Model;
    private int Id;
    private LocalDate year;
    private int price;
    private String color;
    private double engineCapacity;
    private int speedMax;
    private int noDoors;
    private String consumption; // tip de consum
    private String gearbox;//cutia de viteze-manuala, automata
    private String traction;//traciunea-fata,spate,integrala

    public Car() {
    }

    public Car(String brand, String Model, int Id, LocalDate year, int price, String color, double engineCapacity, int speedMax, int noDoors, String consumption, String gearbox, String traction) {
        this.brand = brand;
        this.Model = Model;
        this.Id = Id;
        this.year = year;
        this.price = price;
        this.color = color;
        this.engineCapacity = engineCapacity;
        this.speedMax = speedMax;
        this.noDoors = noDoors;
        this.consumption = consumption;
        this.gearbox = gearbox;
        this.traction = traction;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public int getId() {
        return Id;
    }

    public void setID(int Id) {
        this.Id = Id;
    }

    public LocalDate getYear() {
        return year;
    }

    public void setYear(LocalDate year) {
        this.year = year;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getEngineCapacity() {
        return engineCapacity;
    }

    public void setEngineCapacity(double engineCapacity) {
        this.engineCapacity = engineCapacity;
    }

    public int getSpeedMax() {
        return speedMax;
    }

    public void setSpeedMax(int speedMax) {
        this.speedMax = speedMax;
    }

    public int getNoDoors() {
        return noDoors;
    }

    public void setNoDoors(int noDoors) {
        this.noDoors = noDoors;
    }

    public String getConsumption() {
        return consumption;
    }

    public void setConsumption(String consumption) {
        this.consumption = consumption;
    }

    public String getGearbox() {
        return gearbox;
    }

    public void setGearbox(String gearbox) {
        this.gearbox = gearbox;
    }

    public String getTraction() {
        return traction;
    }

    public void setTraction(String traction) {
        this.traction = traction;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 31 * hash + Objects.hashCode(this.brand);
        hash = 31 * hash + Objects.hashCode(this.Model);
        hash = 31 * hash + Objects.hashCode(this.Id);
        hash = 31 * hash + Objects.hashCode(this.year);
        hash = 31 * hash + this.price;
        hash = 31 * hash + Objects.hashCode(this.color);
        hash = 31 * hash + (int) (Double.doubleToLongBits(this.engineCapacity) ^ (Double.doubleToLongBits(this.engineCapacity) >>> 32));
        hash = 31 * hash + this.speedMax;
        hash = 31 * hash + this.noDoors;
        hash = 31 * hash + Objects.hashCode(this.consumption);
        hash = 31 * hash + Objects.hashCode(this.gearbox);
        hash = 31 * hash + Objects.hashCode(this.traction);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Car other = (Car) obj;
        if (this.price != other.price) {
            return false;
        }
        if (Double.doubleToLongBits(this.engineCapacity) != Double.doubleToLongBits(other.engineCapacity)) {
            return false;
        }
        if (this.speedMax != other.speedMax) {
            return false;
        }
        if (this.noDoors != other.noDoors) {
            return false;
        }
        if (!Objects.equals(this.brand, other.brand)) {
            return false;
        }
        if (!Objects.equals(this.Model, other.Model)) {
            return false;
        }
        if (!Objects.equals(this.Id, other.Id)) {
            return false;
        }
        if (!Objects.equals(this.color, other.color)) {
            return false;
        }
        if (!Objects.equals(this.consumption, other.consumption)) {
            return false;
        }
        if (!Objects.equals(this.gearbox, other.gearbox)) {
            return false;
        }
        if (!Objects.equals(this.traction, other.traction)) {
            return false;
        }
        if (!Objects.equals(this.year, other.year)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Car{" + "brand=" + brand + ", Model=" + Model + ", Id=" + Id + ", year=" + year + ", price=" + price + ", color=" + color + ", engineCapacity=" + engineCapacity + ", speedMax=" + speedMax + ", noDoors=" + noDoors + ", consumption=" + consumption + ", gearbox=" + gearbox + ", traction=" + traction + '}';
    }

 
    
    
}