
package com.sabaltrans.projectnivel1car.models;

import java.time.LocalDate;
import java.util.Objects;

/**
 *
 * @author user
 */
class UserLogin {

    private int id;
    private String username;
    private String password;
    private LocalDate connectionDate;

    public UserLogin() {
    }

    public UserLogin(int id, String username, String password, LocalDate connectionDate) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.connectionDate = connectionDate;
    }

    public LocalDate getConnectionDate() {
        return connectionDate;
    }

    public void setConnectionDate(LocalDate connectionDate) {
        this.connectionDate = connectionDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + Objects.hashCode(this.username);
        hash = 17 * hash + Objects.hashCode(this.connectionDate);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final UserLogin other = (UserLogin) obj;
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        if (!Objects.equals(this.connectionDate, other.connectionDate)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "UserLogin{" + "id=" + id + ", username=" + username + ", password=" + password + ", connectionDate=" + connectionDate + '}';
    }

}
