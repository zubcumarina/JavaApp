package com.sabaltrans.projectnivel1car.gui;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import com.sabaltrans.projectnivel1car.Main;


public class LoginPageFXMLController implements Initializable {

    @FXML
    private TextField tfUsername;
    @FXML
    private PasswordField tfPassword;
    @FXML
    private Label errorMessage;


    Main aRefMain;

    public void setApp(Main aRefMain) {
        this.aRefMain = aRefMain;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void reset(ActionEvent event) {
        tfUsername.setText(" ");
        tfPassword.setText(" ");
    }

    @FXML
    private void login(ActionEvent event) {
        String username = tfUsername.getText();
        String password = tfPassword.getText();

        //validare
        if (tfUsername.getText().isEmpty() || tfPassword.getText().isEmpty()) {
            errorMessage.setText("Username sau password nu poate fi null");
        }
        if (username.length() < 3) {
            errorMessage.setText("Username prea scurt");
        }

        //autentificare
        if (username.equals("admin") && password.equals("123")) {
            aRefMain.gotoAdminPage();
        } else {
            errorMessage.setText("Date incorecte");
        }
    }

    @FXML
    private void back(ActionEvent event) {
        aRefMain.gotoSelectWindow();
    }

}
