package com.sabaltrans.projectnivel1car.gui;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import com.sabaltrans.projectnivel1car.Main;

/**
 * FXML Controller class
 *
 * @author user
 */

public class SelectWindowFXMLController implements Initializable {

    /**
     * Initializes the controller class.
     */
    Main aRefMain;

    public void setApp(Main aRefMain) {
        this.aRefMain = aRefMain;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void accesToPublicUser(ActionEvent event) {
        aRefMain.gotoPublicUser();
    }

    @FXML
    private void accesToLoginPage(ActionEvent event) {
        aRefMain.gotoLoginPage();
    }

}
