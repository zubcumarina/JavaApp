package com.sabaltrans.projectnivel1car.gui;

import com.sabaltrans.projectnivel1car.models.Car;

/**
 *
 * @author user
 */
public interface FormInterface {

    public void clearForm();
    public void fillForm(Car cars);
    Car readForm();
}
