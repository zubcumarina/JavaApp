package com.sabaltrans.projectnivel1car.gui;

import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import com.sabaltrans.projectnivel1car.Main;
import com.sabaltrans.projectnivel1car.models.Car;
import com.sabaltrans.projectnivel1car.dao.CarInterface;
import com.sabaltrans.projectnivel1car.dao.FileIOMockIntf;
import com.sabaltrans.projectnivel1car.dao.implement.CarMockImplement;
import com.sabaltrans.projectnivel1car.dao.implement.FileIOExcelImpl;
import com.sabaltrans.projectnivel1car.dao.implement.FileIOMockImpl;
import com.sabaltrans.projectnivel1car.util.CsvUtil;

public class UserCarController implements Initializable, FormInterface {

    @FXML
    private ComboBox<String> cbBrand;
    @FXML
    private TextField tfModel;   
    @FXML
    private TextField tfId;
    @FXML
    private DatePicker dpYear;
    @FXML
    private TextField tfPrice;
    @FXML
    private ComboBox<String> cbColor;
    @FXML
    private TextField tfEngineCapacity;
    @FXML
    private TextField tfSpeedMax;
    @FXML
    private ComboBox<Integer> cbNoDoors;
    @FXML
    private ComboBox<String> cbConsumption;
    @FXML
    private RadioButton rbManual;
    @FXML
    private ToggleGroup tgGearBox;
    @FXML
    private RadioButton rbAutomat;
    @FXML
    private ComboBox<String> cbTraction;

    @FXML
    private ListView<Car> listView;

    public final static String BMW = "BMW";
    public final static String AUDI = "Audi";
    public final static String MERCEDES = "Mercedes";
    public final static String SKODA = "Skoda";
    public final static String VOLVO = "Volvo";
    public final static String TOYOTA = "Toyota";
    public final static String PORCHE = "Porche";
    public final static String LAND_ROVER = "Land Rover";
    public final static String OPEL = "Opel";
    public final static String MITSUBISHI = "Mitsubishi";
    public final static String RENAULT = "Renault";
    public final static String DACIA = "Dacia";

    public final static String WHITE = "White";
    public final static String BLACK = "Black";
    public final static String BLUE = "Blue";
    public final static String GREEN = "Green";
    public final static String RED = "Red";
    public final static String GRAY = "Gray";
    public final static String BROWN = "Brown";
    public final static String GOLD = "Gold";
    public final static String SILVER = "Silver";

    public final static Integer NODOORS_2 = 2;
    public final static Integer NODOORS_4 = 4;

    public final static String BENZINE = "Benzine";
    public final static String DIESEL = "Diesel";
    public final static String GAS = "Gas";

    public final static String FRONT = "Front";
    public final static String BACK = "Back";
    public final static String INTEGRAL = "Integral";

    //polimorfism, declar interfata ca sa salvam o masina
    CarInterface carMock;
    FileIOMockIntf fileIO;
    FileIOMockIntf fileIOExcel;

    Main aRefMain;
    //Setam tip de date al fiec col
    //init tabel si coloanele
    //inserarea date in tabel

    @FXML
    private TableView<Car> tableView;
    @FXML
    private TableColumn<Car, String> colBrand;
    @FXML
    private TableColumn<Car, String> colModel;  
    @FXML
    private TableColumn<Car, Integer> colId;
    @FXML
    private TableColumn<Car, LocalDate> colYear;
    @FXML
    private TableColumn<Car, Integer> colPrice;
    @FXML
    private TableColumn<Car, String> colColor;  
    @FXML
    private TableColumn<Car, Double> colEngine;
    @FXML
    private TableColumn<Car, Integer> colSpeed;
    @FXML
    private TableColumn<Car, Integer> colDoors;
    @FXML
    private TableColumn<Car, String> colConsum;
     @FXML
    private TableColumn<Car, String> colGearBox;
    @FXML
    private TableColumn<Car, String> colTraction;
 
    

    public void setApp(Main aRefMain) {
        this.aRefMain = aRefMain;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cbBrand.getItems().addAll(BMW, AUDI, MERCEDES, SKODA, VOLVO, TOYOTA, PORCHE,
                LAND_ROVER, OPEL, MITSUBISHI, RENAULT, DACIA);
        cbColor.getItems().addAll(WHITE, BLACK, BLUE, GREEN, RED, GRAY, BROWN, GOLD, SILVER);
        cbNoDoors.getItems().addAll(NODOORS_2, NODOORS_4);
        cbConsumption.getItems().addAll(BENZINE, DIESEL, GAS);
        cbTraction.getItems().addAll(FRONT, BACK, INTEGRAL);

        carMock = new CarMockImplement();
        fileIO = new FileIOMockImpl();
        fileIOExcel = new FileIOExcelImpl();

        listView.getSelectionModel().selectedItemProperty()
                .addListener(new ChangeListener<Car>() {
                    @Override
                    public void changed(ObservableValue<? extends Car> observable,
                            Car oldValue, Car brandSelectat) {
                        fillForm(brandSelectat);
                    }
                }
                );
    }

    public void tableView() {
        initTableView();
        loadDateForTableView();
    }

    @FXML
    private void handleButtonActionSave(ActionEvent event) {
        Car brand = readForm();
        carMock.saveCar(brand);
        refreshListView();
    }

    @FXML
    private void handleButtonActionUpdate(ActionEvent event) {
        Car carModificat = readForm();
        carMock.updateCar(carModificat);
        showFereastraDialog("Update the dates for " + carModificat.getBrand());
        refreshListView();
    }

    @FXML
    private void handleButtonActionDelete(ActionEvent event) {
        Car carRemove = readForm();
        carMock.deleteCar(carRemove);
        showFereastraDialog("Will be delete the " + carRemove.getBrand());
        refreshListView();
    }

    @FXML
    private void handleButtonActionClear(ActionEvent event) {
        clearForm();
    }

    @Override
    public void clearForm() {
        cbBrand.setValue(null);
        tfModel.setText("");
        tfId.setText("");
        dpYear.setValue(null);
        tfPrice.setText("");
        cbColor.setValue(null);
        tfEngineCapacity.setText("");
        tfSpeedMax.setText("");
        cbNoDoors.setValue(0);
        cbConsumption.setValue(null);
        rbManual.setSelected(false);
        rbAutomat.setSelected(false);
        cbTraction.setValue(null);
    }

    public RadioButton gearBoxType() {
        RadioButton gear = (RadioButton) tgGearBox.getSelectedToggle();
        return gear;
    }

    //cautare unui angajat
    @Override
    public void fillForm(Car cars) {
        cbBrand.setValue(cars.getBrand());
        tfModel.setText(cars.getModel());
        tfId.setText(""+cars.getId());
        dpYear.setValue(cars.getYear());
        tfPrice.setText("" + cars.getPrice());
        cbColor.setValue(cars.getColor());
        tfEngineCapacity.setText("" + cars.getEngineCapacity());
        tfSpeedMax.setText("" + cars.getSpeedMax());
        cbNoDoors.setValue(cars.getNoDoors());
        cbConsumption.setValue(cars.getConsumption());
        rbManual.setSelected(false);
        if (cars.getGearbox().equals("Manual")) {
            rbManual.setSelected(true);
        }
        rbAutomat.setSelected(false);
        if (cars.getGearbox().equals("Automat")) {
            rbAutomat.setSelected(true);
        }
        cbTraction.setValue(cars.getTraction());
    }

    @Override
    public Car readForm() {
        Car cars = new Car();
        cars.setBrand(cbBrand.getValue());
        cars.setModel(tfModel.getText());
        cars.setID(Integer.parseInt(tfId.getText()));
        cars.setYear((dpYear.getValue()));
        cars.setPrice(Integer.parseInt(tfPrice.getText()));
        cars.setColor(cbColor.getValue());
        cars.setSpeedMax(Integer.parseInt(tfSpeedMax.getText()));
        cars.setEngineCapacity(Double.parseDouble(tfEngineCapacity.getText()));
        cars.setNoDoors(cbNoDoors.getValue());
        cars.setConsumption(cbConsumption.getValue());
        cars.setGearbox(gearBoxType().getText());
        cars.setTraction(cbTraction.getValue());
        return cars;
    }

    @FXML
    private void handleButtonActionFindById(ActionEvent event) {
        Car idCautat = carMock.findById(Integer.parseInt(tfId.getText()));
        if (idCautat != null) {
            fillForm(idCautat);
        } else {
            showFereastraDialog("There is no car with this id" + tfId.getText());
        }
    }

    @FXML
    private void handleButtonActionFindByBrand(ActionEvent event) {

        Car brandCautat = carMock.findByBrand(cbBrand.getValue());
        if (brandCautat != null) {
            fillForm(brandCautat);
        } else {
            showFereastraDialog("There is no car of this Brand");
        }
    }

    private void refreshListView() {
        List<Car> listCars = carMock.findAll();
      
        listView.getItems().clear();
        listView.getItems().addAll(listCars);
        tableView();
    }

    public void showFereastraDialog(String mesaj) {
        Alert alert = null;

        alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information Dialog");
        alert.setHeaderText(null);
        alert.setContentText(mesaj);
        alert.showAndWait();
    }

    //1. se decla fileiomockinterf
    //2.apoi se initializ
    //3.apel met findall-apelam toate car si se salv intr-o lista  si lista se transm ca param 
    @FXML
    private void handleButtonActionExportCSV(ActionEvent event) {
        //lista cu masini obt prin carMock, la fiecare export nou-ramine ultimul export salvat in mapa proiect
        List<Car> lista = carMock.findAll();
        fileIO.saveToFile("cars.csv", lista);
        showFereastraDialog("The export was successful!");
    }

    @FXML
    private void handleButtonActionImportCSV(ActionEvent event) {
        List<Car> lista = fileIO.readFile("cars.csv");
        carMock = new CarMockImplement(lista);
        refreshListView();
    }

    @FXML
    private void handleButtonActionImportExcel(ActionEvent event) {
        List<Car> lista = fileIOExcel.readFile("carSabalTrans.xls");
        carMock = new CarMockImplement(lista); //init cu lista din excel
        refreshListView();
    }

    @FXML
    private void handleButtonActionExportExcel(ActionEvent event) {
        List<Car> lista = carMock.findAll();
        fileIOExcel.saveToFile("carSabalTrans.xls", lista);

        showFereastraDialog("The exportExcel was successful!");
        refreshListView();
    }

    @FXML
    private void back(ActionEvent event) {
        aRefMain.gotoSelectWindow();
    }

    private void initTableView() {
        colBrand.setCellValueFactory(new PropertyValueFactory<>("brand"));
        colModel.setCellValueFactory(new PropertyValueFactory<>("Model"));
        colId.setCellValueFactory(new PropertyValueFactory<>("Id"));
        colYear.setCellValueFactory(new PropertyValueFactory<>("year"));
        colPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        colColor.setCellValueFactory(new PropertyValueFactory<>("color"));
        colEngine.setCellValueFactory(new PropertyValueFactory<>("engineCapacity"));
        colSpeed.setCellValueFactory(new PropertyValueFactory<>("speedMax"));
        colDoors.setCellValueFactory(new PropertyValueFactory<>("noDoors"));
        colConsum.setCellValueFactory(new PropertyValueFactory<>("consumption"));
        colGearBox.setCellValueFactory(new PropertyValueFactory<>("gearBox"));
        colTraction.setCellValueFactory(new PropertyValueFactory<>("traction"));
    }

    private void loadDateForTableView() {
        List<Car> listCars = new ArrayList<>();
        listCars = carMock.findAll();

        String rind = null;
        //parcurge lista si extrage cite un rind
        while (rind != null) {
            Car car = CsvUtil.lineToCar(rind);
            listCars.add(car);
        }

        ObservableList<Car> tabelData = FXCollections.observableArrayList();
        for (Car car : listCars) {
            tabelData.add(new Car(
                    car.getBrand(),
                    car.getModel(),
                    car.getId(),
                    car.getYear(),
                    car.getPrice(),
                    car.getColor(),
                    car.getEngineCapacity(),
                    car.getSpeedMax(),
                    car.getNoDoors(),
                    car.getConsumption(),
                    car.getGearbox(),
                    car.getTraction()));
        }
        tableView.setItems(tabelData);
    }

}
