/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sabaltrans.projectnivel1car.db;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class DataSource {
     private static final Logger LOG = Logger.getLogger(DataSource.class.getName());

    private String dbUserName;//user cind sa creat baza de date (root)
    private String dbPassword;//parola userului cind sa creat bd
    private String dbUrl;//calea unde se afla db
    private String dbName;

    private String dbDriverName;

    private Connection connection;

    private DataSource() {
        try {
            loadProperties();
            testConnection();
        } catch (SQLException ex) {
            LOG.severe(ex.toString());
        } catch (IOException ex) {
            Logger.getLogger(DataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Connection getConnection() throws SQLException {
        if (connection == null || (connection != null && connection.isClosed())) {
            connection = DriverManager.getConnection(dbUrl, dbUserName, dbPassword);
        }
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public static DataSource getInstance() {

        return DataBaseHolder.INSTANCE;
    }

    private static class DataBaseHolder {

        private static final DataSource INSTANCE = new DataSource();
    }

    private void loadProperties() throws FileNotFoundException, IOException {
        //continutul fisierului de proprietati
        //key = valoare 
//        dbUserName = "root";
//        dbPassword = "free";
//        dbName = "dblevel2";
//        dbDriverName = "org.apache.derby.jdbc.ClientDriver";
//        dbUrl = "jdbc:derby://localhost:1527/" + dbName;

        Properties pr = new Properties();
        pr.load(new FileReader("jdbc.properties"));

        dbUserName = pr.getProperty("dbUserName");
        dbPassword = pr.getProperty("dbPassword");
        dbName = pr.getProperty("dbName");
        dbDriverName = pr.getProperty("dbDriverName");
        dbUrl = pr.getProperty("dbUrl");

        LOG.info("S-a incarcat fisierul de proprietati!");

    }

    private void testConnection() throws SQLException {
        if (getConnection() != null) {

            LOG.info("Conectat cu succes la Baza de Date");
        }
    }
}
